#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import time
from pip._vendor.colorama import Fore, Style, Back
from slowprint.slowprint import *




time.sleep(2.0)
os.system("cls")

art = '''

 ⠀⣰⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ ⠀⠀⠀⠀  ⠀⠐⣆⠀⠀
 ⣴⠁⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ ⠀⠀⠀⠀ ⠀ ⢀⠃⢣⠀
 ⢻⠀⠸⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ ⠀⠀⠀⠀  ⠀⡜⠀⢸⠇
 ⠘⡄⢆⠑⡄⠀⠀⠀⠀⠀⢀⣀⣀⣠⣄⣀⣀⡀⠀⠀ ⠀⠀ ⢀⠜⢠⢀⡆⠀
 ⠀⠘⣜⣦⠈⢢⡀⣀⣴⣾⣿⡛⠛⠛⠛⠛⠛⡿⣿⣦⣄⡠⠋⣰⢧⠎⠀⠀
⠀ ⠀⠘⣿⣧⢀⠉⢻⡟⠁⠙⠃⠀⠀⠀⠀⠈⠋⠀⠹⡟⠉⢠⢰⣿⠏⠀⠀⠀
⠀⠀ ⠀⠘⣿⡎⢆⣸⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⣿⣠⢣⣿⠏⠀⠀⠀⠀
⠀⠀ ⠀⡖⠻⣿⠼⢽⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⠹⣾⠟⢳⡄⠀⠀⠀
⠀⠀ ⠀⡟⡇⢨⠀⢸⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡎⠀⣇⢠⢿⠇⠀⠀⠀
⠀⠀ ⠀⢹⠃⢻⡤⠚⠀⠀⠀⠀⣀⠀⠀⢀⠀⠀⠀⠀⠙⠢⡼⠀⢻⠀⠀⠀⠀
⠀⠀ ⠀⠸⡓⡄⢹⠦⠤⠤⠤⢾⣇⠀⠀⢠⡷⠦⠤⠤⠴⢺⢁⠔⡟⠀⠀⠀⠀
⠀⠀ ⠀⢠⠁⣷⠈⠓⠤⠤⠤⣞⡻⠀⠀⢸⣱⣤⠤⠤⠔⠁⣸⡆⣇⠀⠀⠀⠀
⠀⠀ ⠀⠘⢲⠋⢦⣀⣠⢴⠶⠀⠁⠀⠀⠈⠁⠴⣶⣄⣀⡴⠋⣷⠋⠀⠀⠀⠀
⠀⠀ ⠀⠀⣿⡀⠀⠀⢀⡘⠶⣄⡀⠀⠀⠀⣠⡴⠞⣶⠀⢀⠀⣼⠀⠀⠀⠀⠀
⠀⠀ ⠀⠀⠈⠻⣌⢢⢸⣷⣸⡈⠳⠦⠤⠞⠁⣷⣼⡏⣰⢃⡾⠋⠀⠀⠀⠀⠀
⠀⠀ ⠀⠀⠀⠀⠙⢿⣿⣿⡇⢻⡶⣦⣤⡴⡾⢸⣿⣿⣷⠏⠀⠀⠀⠀⠀⠀⠀
⠀⠀ ⠀⠀⠀⠀⠀⠀⢿⡟⡿⡄⣳⣤⣤⣴⢁⣾⠏⡿⠁⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀ ⠀⠀⠀⠀⠀⠀⠈⣷⠘⠒⠚⠉⠉⠑⠒⠊⣸⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀ ⠀⠀⠀⠀⠀⠀⠀⠈⠳⠶⠔⠒⠒⠲⠴⠞⠋⠀⠀

'''

print(Fore.RED+art)

time.sleep(3.0)
slowprint(Fore.RED+"Evil of R1Px0x8: SENİ SALAK !!!"+Fore.RESET,1.0)
time.sleep(2.0)
slowprint(Fore.RED+"Evil of R1Px0x8: Gerçekten buna inandınmı???"+Fore.RESET,1.0)
slowprint(Fore.RED+"Evil of R1Px0x8: Birde Siber Güvenlikçi, yazılımcı olacaksın..."+Fore.RESET,1.0)
slowprint(Fore.RED+"Evil of R1Px0x8: Hacklendin dostum... Dosyalarının hepsini ele geçirdim."+Fore.RESET,0.3)
time.sleep(2.0)

slowprint("3",2.0)
slowprint("2",2.0)
slowprint("1",2.0)
slowprint("0",2.0)

os.system('cls' if os.name == 'nt' else 'clear')

def colorful_banner(text, speed=0.1, duration=4):
    colors = [Fore.RED, Fore.GREEN, Fore.YELLOW, Fore.BLUE, Fore.MAGENTA, Fore.CYAN]
    index = 0
    start_time = time.time()
    while time.time() - start_time < duration:
        os.system('cls' if os.name == 'nt' else 'clear')
        colored_text = colors[index % len(colors)] + Back.BLACK + text + Style.RESET_ALL
        print(colored_text)
        time.sleep(speed)
        index += 1
        os.system('cls' if os.name == 'nt' else 'clear')


colorful_banner("""

.########.########..########...#######..########.
.##.......##.....##.##.....##.##.....##.##.....##
.##.......##.....##.##.....##.##.....##.##.....##
.######...########..########..##.....##.########.
.##.......##...##...##...##...##.....##.##...##..
.##.......##....##..##....##..##.....##.##....##.
.########.##.....##.##.....##..#######..##.....##

""", speed=0.1, duration=4)




